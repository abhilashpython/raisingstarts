def fun1():
	return "fun1 in f1"
print "executed f1"