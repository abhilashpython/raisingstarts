def fun2():
	return "fun2 in f2"
print "executed f2"