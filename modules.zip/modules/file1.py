def fun1():
	return 10+200+50