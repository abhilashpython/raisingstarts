
def fun3():
	return "fun3 in file3"
if __name__ == '__main__':
	def fun4():
		print "fun4 in file3"
	print "program started in file3"
	print fun2()
	print "program ended in file3"