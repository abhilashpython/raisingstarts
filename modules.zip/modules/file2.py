print "program started"
def fun2():
	return "fun2 in file2"
print fun2()
print "program ended"